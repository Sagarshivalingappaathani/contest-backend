# LeetCode Contest Backend

## Setup

1. Copy `.env.example` to `.env` and fill in DB and Redis details.
2. Install dependencies:
   ```
   npm install
   ```
3. Initialize DB schema (example using psql):
   ```sql
   CREATE TABLE problems (
     id SERIAL PRIMARY KEY,
     title TEXT,
     statement TEXT,
     input_format TEXT,
     output_format TEXT,
     constraints TEXT,
     sample_io JSONB,
     time_limit INT,
     memory_limit INT
   );
   CREATE TABLE submissions (
     id SERIAL PRIMARY KEY,
     user_id INT,
     problem_id INT,
     code TEXT,
     status TEXT,
     verdict TEXT,
     time INT,
     memory INT,
     contest_id INT
   );
   ```
4. Build Docker image for judge:
   ```
   cd docker-runner
   docker build -t leetcode-judge .
   cd ..
   ```
5. Start server:
   ```
   npm start
   ```
6. Start worker:
   ```
   npm run worker
   ```

## API Endpoints

- GET `/api/problem/:id`
- POST `/api/submit`  `{ user_id, problem_id, code }`
- GET `/api/result/:id`
- GET `/api/leaderboard/:contestId}`
