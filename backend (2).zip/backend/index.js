require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
const Queue = require('bull');
const http = require('http');
const { Server } = require('socket.io');

// Validate required environment variables
const requiredEnvVars = ['PGHOST', 'PGPORT', 'PGUSER', 'PGPASSWORD', 'PGDATABASE', 'REDIS_URL'];
const missingVars = requiredEnvVars.filter(varName => !process.env[varName]);

if (missingVars.length > 0) {
  console.error('Missing required environment variables:', missingVars);
  process.exit(1);
}

const app = express();
app.use(bodyParser.json());

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

// Postgres pool
const pool = new Pool();

// Redis queue
const submissionQueue = new Queue('submissions', process.env.REDIS_URL);

// Routes
app.get('/api/problem/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      'SELECT id, title, statement, input_format, output_format, constraints, sample_io, time_limit, memory_limit FROM problems WHERE id=$1', 
      [id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Problem not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error fetching problem:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.post('/api/submit', async (req, res) => {
  try {
    const { user_id, problem_id, code } = req.body;
    
    // Validate input
    if (!user_id || !problem_id || !code) {
      return res.status(400).json({ error: 'Missing required fields' });
    }
    
    if (code.length > 50000) { // 50KB limit
      return res.status(400).json({ error: 'Code too long' });
    }
    
    const insert = await pool.query(
      'INSERT INTO submissions(user_id, problem_id, code, status) VALUES($1,$2,$3,$4) RETURNING id',        
      [user_id, problem_id, code, 'QUEUE']
    );
    
    const submissionId = insert.rows[0].id;
    await submissionQueue.add({ submissionId });
    res.json({ submissionId });
    
  } catch (error) {
    console.error('Error submitting:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/api/result/:id', async (req, res) => {
  const { id } = req.params;
  const result = await pool.query('SELECT * FROM submissions WHERE id=$1', [id]);
  res.json(result.rows[0] || {});
});

app.get('/api/leaderboard/:contestId', async (req, res) => {
  // Simplified: returns last 10 submissions
  const { contestId } = req.params;
  const result = await pool.query('SELECT user_id, problem_id, verdict, time, memory FROM submissions WHERE contest_id=$1 AND verdict=$2 ORDER BY time ASC LIMIT 10', [contestid, 'AC']);
  res.json(result.rows);
});

// Socket.IO for real-time updates
submissionQueue.on('completed', (job, result) => {
  io.emit('submission_complete', { submissionId: job.data.submissionId, result });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
