-- Create database tables
CREATE TABLE IF NOT EXISTS problems (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    statement TEXT NOT NULL,
    input_format TEXT,
    output_format TEXT,
    constraints TEXT,
    sample_io JSONB NOT NULL, -- Array of {input, output} objects
    time_limit INTEGER DEFAULT 1000, -- milliseconds
    memory_limit INTEGER DEFAULT 256, -- MB
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS submissions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    problem_id INTEGER REFERENCES problems(id),
    contest_id INTEGER,
    code TEXT NOT NULL,
    language VARCHAR(50) DEFAULT 'cpp',
    status VARCHAR(20) DEFAULT 'QUEUE', -- QUEUE, RUNNING, DONE
    verdict VARCHAR(10), -- AC, WA, TLE, MLE, CE, RE
    time INTEGER DEFAULT 0, -- execution time in ms
    memory INTEGER DEFAULT 0, -- memory usage in KB
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Add indexes for better performance
CREATE INDEX idx_submissions_user_id ON submissions(user_id);
CREATE INDEX idx_submissions_problem_id ON submissions(problem_id);
CREATE INDEX idx_submissions_contest_id ON submissions(contest_id);