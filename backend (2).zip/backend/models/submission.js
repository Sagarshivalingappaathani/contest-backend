// models/submission.js
const { Pool } = require('pg');
const pool = new Pool();

module.exports = {
  /**
   * Create a new submission record (status = QUEUE)
   * @param {number} userId
   * @param {number} problemId
   * @param {string} code
   * @param {number} contestId
   * @returns {Promise<number>} the new submission ID
   */
  async create(userId, problemId, code, contestId = null) {
    const res = await pool.query(
      `INSERT INTO submissions
         (user_id, problem_id, code, status, contest_id)
       VALUES ($1, $2, $3, 'QUEUE', $4)
       RETURNING id`,
      [userId, problemId, code, contestId]
    );
    return res.rows[0].id;
  },

  /**
   * Fetch a submission by its ID
   * @param {number} id
   * @returns {Promise<object>}
   */
  async getById(id) {
    const res = await pool.query(
      `SELECT * FROM submissions WHERE id = $1`,
      [id]
    );
    return res.rows[0] || null;
  },

  /**
   * Update the verdict and resource usage of a submission
   * @param {number} id
   * @param {string} verdict
   * @param {number} timeMs
   * @param {number} memoryKb
   * @returns {Promise<void>}
   */
  async updateResult(id, verdict, timeMs = 0, memoryKb = 0) {
    await pool.query(
      `UPDATE submissions
         SET status = 'DONE',
             verdict = $1,
             time = $2,
             memory = $3
       WHERE id = $4`,
      [verdict, timeMs, memoryKb, id]
    );
  },

  /**
   * Get the top N accepted submissions for a contest (leaderboard)
   * @param {number} contestId
   * @param {number} limit
   * @returns {Promise<object[]>}
   */
  async getLeaderboard(contestId, limit = 10) {
    const res = await pool.query(
      `SELECT user_id,
              problem_id,
              verdict,
              time,
              memory
       FROM submissions
       WHERE contest_id = $1
         AND verdict = 'AC'
       ORDER BY time ASC
       LIMIT $2`,
      [contestId, limit]
    );
    return res.rows;
  }
};
