// models/problem.js
const { Pool } = require('pg');
const pool = new Pool();

module.exports = {
  /**
   * Fetch a problem by ID
   * @param {number} id
   * @returns {Promise<object>}
   */
  async getById(id) {
    const res = await pool.query(
      `SELECT
         id, title, statement,
         input_format, output_format,
         constraints, sample_io,
         time_limit, memory_limit
       FROM problems
       WHERE id = $1`,
      [id]
    );
    return res.rows[0] || null;
  },

  /**
   * (Optional) List all problems for a contest
   * @param {number[]} ids
   * @returns {Promise<object[]>}
   */
  async getMany(ids) {
    const res = await pool.query(
      `SELECT
         id, title, statement,
         input_format, output_format,
         constraints, sample_io,
         time_limit, memory_limit
       FROM problems
       WHERE id = ANY($1::int[])`,
      [ids]
    );
    return res.rows;
  }
};
