#include <bits/stdc++.h>
#include <sys/resource.h>
#include <unistd.h>
using namespace std;

int main() {
    // Set resource limits
    struct rlimit rl;
    
    // CPU time limit (5 seconds)
    rl.rlim_cur = rl.rlim_max = 5;
    setrlimit(RLIMIT_CPU, &rl);
    
    // Compile the solution
    int compile_result = system("cd /mnt/code && g++ -o Solution.out Solution.cpp -std=c++17 2>compile_error.txt");
    
    if (compile_result != 0) {
        // Compilation failed
        system("echo 'Compilation Error' > /mnt/code/output.txt");
        return 1;
    }
    
    // Execute the solution
    int exec_result = system("cd /mnt/code && timeout 5s ./Solution.out < input.txt > output.txt 2>runtime_error.txt");
    
    return exec_result;
}