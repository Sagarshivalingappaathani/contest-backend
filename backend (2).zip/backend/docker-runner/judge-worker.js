require('dotenv').config();
const Queue = require('bull');
const { Pool } = require('pg');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const pool = new Pool();
const submissionQueue = new Queue('submissions', process.env.REDIS_URL);

submissionQueue.process(async job => {
  const { submissionId } = job.data;
  
  try {
    // Fetch submission and problem
    const subRes = await pool.query('SELECT * FROM submissions WHERE id=$1', [submissionId]);
    const submission = subRes.rows[0];
    
    if (!submission) {
      throw new Error(`Submission ${submissionId} not found`);
    }
    
    const probRes = await pool.query('SELECT * FROM problems WHERE id=$1', [submission.problem_id]);
    const problem = probRes.rows[0];
    
    if (!problem) {
      throw new Error(`Problem ${submission.problem_id} not found`);
    }

    // Update status to RUNNING
    await pool.query('UPDATE submissions SET status=$1 WHERE id=$2', ['RUNNING', submissionId]);

    // Prepare workspace
    const workDir = path.join(__dirname, 'work', `${submissionId}`);
    fs.mkdirSync(workDir, { recursive: true });
    fs.writeFileSync(path.join(workDir, 'Solution.cpp'), submission.code);
    
    // Write sample input (handle multiple test cases)
    const sampleInput = problem.sample_io[0]?.input || '';
    fs.writeFileSync(path.join(workDir, 'input.txt'), sampleInput);

    // Run Docker container with timeout
    const docker = spawn('docker', [
      'run', '--rm',
      '-v', `${workDir}:/mnt/code`,
      '--memory', `${problem.memory_limit}m`,
      '--cpus', '0.5',
      '--network', 'none', // Security: no network access
      'leetcode-judge',
    ]);

    let timeout = setTimeout(() => {
      docker.kill();
    }, problem.time_limit + 5000); // Add 5s buffer

    docker.on('exit', async (code) => {
      clearTimeout(timeout);
      
      try {
        // Check if output file exists
        const outputPath = path.join(workDir, 'output.txt');
        if (!fs.existsSync(outputPath)) {
          await pool.query('UPDATE submissions SET status=$1, verdict=$2 WHERE id=$3', 
            ['DONE', 'RE', submissionId]);
          return;
        }

        const output = fs.readFileSync(outputPath, 'utf8').trim();
        const expectedOutput = problem.sample_io[0]?.output?.trim() || '';
        
        let verdict = 'WA';
        if (code === 0 && output === expectedOutput) {
          verdict = 'AC';
        } else if (code !== 0) {
          verdict = 'RE'; // Runtime Error
        }

        await pool.query('UPDATE submissions SET status=$1, verdict=$2, time=$3, memory=$4 WHERE id=$5', 
          ['DONE', verdict, 0, 0, submissionId]);
        
        // Clean up workspace
        fs.rmSync(workDir, { recursive: true, force: true });
        
      } catch (error) {
        console.error('Error processing result:', error);
        await pool.query('UPDATE submissions SET status=$1, verdict=$2 WHERE id=$3', 
          ['DONE', 'RE', submissionId]);
      }
    });

  } catch (error) {
    console.error('Error processing submission:', error);
    await pool.query('UPDATE submissions SET status=$1, verdict=$2 WHERE id=$3', 
      ['DONE', 'RE', submissionId]);
  }
});

console.log('Judge worker started...');